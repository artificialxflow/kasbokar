import React from 'react';

function App() {
  return (
    <iframe src="../index.html" style={{ width: '100%', height: '100vh', border: 'none' }} />
  );
}

export default App;
